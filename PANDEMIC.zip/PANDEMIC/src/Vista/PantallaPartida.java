package Vista;

public class PantallaPartida {

	
public PantallaPartida(){
	
}
	
public void empezarNuevaPartida() {
	
}
public void empezarPartidaGuardada(String id) {
	
}
public void funBotonCurarCiudad(String nCiudad) {
	
}
public void funBotonDesarrollarVacuna(String nVacuna) {
	
}
public void funBotonFinalizarTurno() {
	
}
public void funBotonGuardarPartida() {
	
}
public void funBotonnuevaPartida() {
	
}
public void funBotonçVolverInicio() {
	
}




	
}
