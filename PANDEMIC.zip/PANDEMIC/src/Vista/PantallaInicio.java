package Vista;

public class PantallaInicio {

	
public  PantallaInicio(){
	
}

public void cargarPantallaInicio() {
	
}
public void cargarRecords() {
	
}
public void cargarPantallaGuardado() {
	
}
public void cargarPartida() {
	
}

}

