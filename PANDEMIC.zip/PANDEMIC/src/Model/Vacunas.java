package Model;

/**
 * Clase que define el objeto vacunas.
 */
public class Vacunas {

	public  String nombre;
	private  String color;
	public  int porcentaje=0;
	
	/*
	 * Constructor del objeto
	 */
	public  Vacunas() {
		
	}

	/**
	 * Constructor con parametros
	 * @param String nombre
	 * @param String color
	 * @param int pDesarrollo
	 */
	public Vacunas(String nombre, String color, int p) {
		
		this.nombre = nombre;
		this.color = color;
		this.porcentaje = p;
	}


	/**
	 * Establece el valor de la propiedad nombre.
	 *
	 * @param String nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Obtiene el valor de la propiedad nombre.
	 *
	 * @return String nombre
	 */
	public String getNombre() {
		return this.nombre;
	}
	
	/**
	 * Establece el valor de la propiedad color.
	 *
	 * @param String color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * Obtiene el valor de la propiedad color.
	 *
	 * @return String color
	 */
	public String getColor() {
		return this.color;
	}  
	/**
	 * Establece el valor de la propiedad porcentaje.
	 *
	 * @param int porcentaje
	 */
	public void setPorcentaje(int porcentaje) {
		this.porcentaje = porcentaje;
	}
	/**
	 * Obtiene el valor de la propiedad porcentaje.
	 *
	 * @return int porcentaje
	 */
	public int getPorcentaje() {
		return this.porcentaje;
	}

	/**
	 * Aumenta el porcentaje para una vacuna
	 *
	 * @param int porcentaje
	 */
	public  void desarrollarVacuna(int porcentaje) {
		
		this.porcentaje +=porcentaje;
		
		
	}
	
}