package Model;


/**
 * Clase que define el objeto virus.
 */
public class Virus {
	
	private String identificador;
	private String nombre;
	private String color;
	
	/**
	 * Constructor del objeto sin parametros
	 */
	public Virus() {
		
	}
	/**
	 * Constructor del objeto ocn parametros
	 */
	public Virus(String identificador, String nombre, String color) {
		this.identificador = identificador;
		this.nombre = nombre;
		this.color = color;
	}
	
	/**
	 * Establece el valor de la propiedad identificador.
	 *
	 * @param String identificador
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	/**
	 * Obtiene el valor de la propiedad identificador.
	 *
	 * @return String identificador
	 */
	public String getidentificador() {
		return this.identificador;
	}  
	
	/**
	 * Establece el valor de la propiedad nombre.
	 *
	 * @param String nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Obtiene el valor de la propiedad nombre.
	 *
	 * @return String nombre
	 */
	public String getNombre() {
		return this.nombre;
	}  
	
	/**
	 * Establece el valor de la propiedad color.
	 *
	 * @param String color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * Obtiene el valor de la propiedad color.
	 *
	 * @return String color
	 */
	public String getColor() {
		return this.color;
	}
	
	


}