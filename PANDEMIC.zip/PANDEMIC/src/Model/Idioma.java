package Model;

/**
 * Clase que contiene segun el idioma en ArrayList, palabras y frases.
 */
public class Idioma {

}
