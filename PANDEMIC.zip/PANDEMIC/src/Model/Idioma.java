package Model;

public class Idioma {

}
