package Model;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Clase donde se definen los objetos ciudad
 * 
 */
public class Ciudad {

	public String nombre;
	public int[] coordenadas;
	public String enfermedad;
	public int infeccion = 0;
	public String[] ciudadesColindantes;

	public Ciudad() {

	}

	/**
	 * Constructor con parametros
	 * @param String nombre
	 * @param int[] coordenadas
	 * @param int infeccion
	 * @param String[] ciudadesColindantes
	 */
	public Ciudad(String nombre, int[] coordenadas, String enfermedad, int infeccion, String[] ciudadesColindantes) {
		this.nombre = nombre;
		this.coordenadas = coordenadas;
		this.enfermedad = enfermedad;
		this.infeccion = infeccion;
		this.ciudadesColindantes = ciudadesColindantes;
	}

	/**
	 * Establece el valor de la propiedad nombre.
	 *
	 * @param nombre el nuevo valor de la propiedad nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Obtiene el valor de la propiedad nombre.
	 *
	 * @return el valor actual de la propiedad nombre
	 */
	public String getNombre() {
		return this.nombre;
	}

	/**
	 * Establece el valor de la propiedad coordenadas.
	 *
	 * @param int[] coordenadas 
	 */
	public void setCoordenadas(int[] coordenadas) {
		this.coordenadas = coordenadas;
	}

	/**
	 * Obtiene el valor de la propiedad coordenadas.
	 *
	 * @return int[] coordenadas 
	 */
	public int[] getCoordenadas() {
		return this.coordenadas;
	}

	/**
	 * Establece el valor de la propiedad enfermedad.
	 *
	 * @param String enfermedad
	 */
	public void setEnfermedad(String enfermedad) {
		this.enfermedad = enfermedad;
	}

	/**
	 * Obtiene el valor de la propiedad enfermedad.
	 *
	 * @return String getEnfermedad
	 */
	public String getEnfermedad() {
		return this.enfermedad;
	}

	/**
	 * Establece el valor de la propiedad infeccion.
	 *
	 * @param int infeccion
	 */
	public void setInfeccion(int infeccion) {
		this.infeccion = infeccion;
	}

	/**
	 * Obtiene el valor de la propiedad infeccion.
	 *
	 * @return int Infeccion
	 */
	public int getInfeccion() {
		return this.infeccion;
	}

	/**
	 * Establece el valor de la propiedad String[] ciudadesColindantes.
	 *
	 * @param String[] ciudadesColindantes
	 */
	public void setCiudadesColindantes(String[] ciudadesColindantes) {
		this.ciudadesColindantes = ciudadesColindantes;
	}

	/**
	 * Obtiene el valor de la propiedad String[] CiudadesColindantes
	 *
	 * @return String[] CiudadesColindantes
	 */
	public String[] getCiudadesColindantes() {
		return this.ciudadesColindantes;
	}

	/**
	 * Aumenta la infección para una ciudad.
	 *
	 * @return infeccion
	 */
	public void aumentarInfeccion() {
		this.infeccion++;
	}

	/**
	 * Disminuye la infección para una ciudad.
	 *
	 * @return infeccion
	 */
	public void disminuirInfeccion() {
		this.infeccion--;
	}

	/**
	 * Metodo de respaldo para gestionar las ciudades colindantes
	 *
	 * @param ArrayList<Ciudad> x
	 */
	public void propagarInfeccion(ArrayList<Ciudad> x) {

		if (this.infeccion == 3) {
			for (int i = 0; i < this.ciudadesColindantes.length; i++) {

				for (int j = 0; i < 48; j++) {

					if (this.ciudadesColindantes[i].equals(x.get(j).nombre)) {
						x.get(j).setEnfermedad(this.enfermedad);
						x.get(j).aumentarInfeccion();
					}

				}

			}
		}

	}

	@Override
	public String toString() {
		return "Ciudad [nombre=" + nombre + ", coordenadas=" + Arrays.toString(coordenadas) + ", enfermedad="
				+ enfermedad + ", infeccion=" + infeccion + ", ciudadesColindantes="
				+ Arrays.toString(ciudadesColindantes) + "]";
	}

}
