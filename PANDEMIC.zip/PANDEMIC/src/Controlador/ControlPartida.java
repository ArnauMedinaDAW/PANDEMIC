package Controlador;



import Model.*;
import Swing.*;

/**
 * Controlador del juego, realiza los turnos y los cambios de valores.
 */
public class ControlPartida {

	public static boolean seguirJuego = true;
	public static boolean victoria = false;
	public static boolean newGame;

	/**
	 * Constructor de la clase Inicia con los metodos de cargar parametros
	 */
	public ControlPartida() {

		// Cargar datos partida inicio
		ControlDatos.cargarParametrosInicioCiudades();
		DatosPartida.numEnfermedadesActivas = ControlDatos.numCiudadesInfectadasInicio;
		DatosPartida.randomitzarCiutatsIniciInfectades();

	}

	/**
	 * Gestionar turno del juego
	 * 
	 * Gestiona las infecciones, brotes, interfaz grafica y condiciones de victoria
	 * 
	 */
	public static void gestionarTurno() {

		DatosPartida.acciones = 4;
		Juego.lblaccionesRestantes.setText(String.valueOf(DatosPartida.acciones));

		gestionarNuevasInfecciones();// Per cada turn,s'agreguen infecions
		gestionarInfeccionesColindantes();
		Juego.Infectadas.setText(String.valueOf(DatosPartida.numEnfermedadesActivas));
		gestionarBrotes();
		gestionarProgressBar();
		gestionarFrases();// Frases generades per turn
		ciudadesVisibles();
		gestionarFinPartida();

	}

	/**
	 * gestiona infecciones por turno Por cada turno genera las infecciones
	 * correspondientes a la dificultad
	 * 
	 */
	public static void gestionarNuevasInfecciones() {

		// RANDOMITZAR LES CIUTATS INFECTADES PER TORN

		int maxValue = DatosPartida.ciutats.size();
		int random = 0;
		int i = 0;
		while (i != ControlDatos.numCuidadesInfectadasRonda) {
			random = (int) (Math.random() * maxValue);

			if (DatosPartida.ciutats.get(random).infeccion != 3) {
				DatosPartida.ciutats.get(random).infeccion++;
				if (DatosPartida.ciutats.get(random).infeccion == 1) {
					DatosPartida.numEnfermedadesActivas++;
				}

			}
			i++;
		}

	}

	/**
	 * gestiona infecciones de colindantes por turno Por cada turno genera recorre
	 * las ciudades con brotes e infecta sus colindantes
	 * 
	 */
	public static void gestionarInfeccionesColindantes() {

		// Recorrer totes les ciutats
		for (int i = 0; i < DatosPartida.ciutats.size(); i++) {
			// Buscar una ciutat amb brot
			if (DatosPartida.ciutats.get(i).infeccion == 3) {

				// Buscar els noms de les ciutats colindants de la ciutat amb brot
				for (int j = 0; j < DatosPartida.ciutats.get(i).ciudadesColindantes.length; j++) {
					// Per cada ciutat colindant recorrer totes les ciutats fins trobar l'index del
					// objecte respecte la ciutat colindant
					for (int x = 0; x < DatosPartida.ciutats.size(); x++) {
						// Index del objecte colindant
						if (DatosPartida.ciutats.get(x).nombre
								.equals(DatosPartida.ciutats.get(i).ciudadesColindantes[j])) {
							// Si la colindant no te 3 en infecció, aumenta
							if (DatosPartida.ciutats.get(x).infeccion != 3) {
								DatosPartida.ciutats.get(x).infeccion++;
								// Si no estava infectada, aumenta el num de infectades Actives
								if (DatosPartida.ciutats.get(x).infeccion == 1) {
									DatosPartida.numEnfermedadesActivas++;
								}

							}
						}
					}
				}
			}
		}
	}

	/**
	 * gestiona los brotes por turno. Si una ciudad llega a nivel 3 de infeccion, se
	 * genera un nuevo brote.
	 * 
	 */
	public static void gestionarBrotes() {

		int numBrotes = 0;

		for (int i = 0; i < DatosPartida.ciutats.size(); i++) {

			if (DatosPartida.ciutats.get(i).infeccion == 3) {
				numBrotes++;
				Juego.frases.add("!Nuevo Brote! - " + DatosPartida.ciutats.get(i).nombre);

			}

			DatosPartida.brotes = numBrotes;

		}
		Juego.Brotes.setText(String.valueOf(DatosPartida.brotes));
	}

	/**
	 * gestiona las frases por turno. Se muestran las frases en una Lista en la
	 * interfax con informacion de las ciudades
	 * 
	 */
	public static void gestionarFrases() {

		for (int i = 0; i < DatosPartida.ciutats.size(); i++) {
			if (DatosPartida.ciutats.get(i).getInfeccion() != 0) {
				Juego.frases.add(DatosPartida.ciutats.get(i).getNombre() + " nivel "
						+ DatosPartida.ciutats.get(i).getInfeccion());
			}
		}

	}

	/**
	 * gestiona el fin de partida. Genera las condiciones de victoria y derrota. En
	 * cada turno verifica el estado de la partida.
	 * 
	 */
	public static void gestionarFinPartida() {

		if (DatosPartida.brotes >= ControlDatos.numBrotesDerrota) {

			seguirJuego = false;
			System.out.println("PIERDES POR BROTES");
		}
		if (DatosPartida.numEnfermedadesActivas >= ControlDatos.numEnfermedadesActivasDerrota) {
			seguirJuego = false;
			System.out.println("PIERDES POR INFECCIONES");
		}
		if (DatosPartida.vacunas.get(0).porcentaje == 100 && DatosPartida.vacunas.get(1).porcentaje == 100
				&& DatosPartida.vacunas.get(2).porcentaje == 100 && DatosPartida.vacunas.get(3).porcentaje == 100) {

			victoria = true;
		}

	}

	/**
	 * gestionar progressBar cada turno actualiza el contador de desarrollo medido
	 * en distintas progressBar
	 * 
	 */
	public static void gestionarProgressBar() {

		Juego.progressBarAlfa.setValue(DatosPartida.vacunas.get(0).porcentaje);
		Juego.progressBarBeta.setValue(DatosPartida.vacunas.get(1).porcentaje);
		Juego.progressBarGama.setValue(DatosPartida.vacunas.get(2).porcentaje);
		Juego.progressBarDelta.setValue(DatosPartida.vacunas.get(3).porcentaje);

	}

	/**
	 * gestiona las ciudades visibles en el mapa. En cada tuerno se recorren todas
	 * las ciudades, se actualizan en la interfaz dependiendo de su estado de
	 * infeccion.
	 * 
	 */
	public static void ciudadesVisibles() {

		for (int i = 0; i < DatosPartida.ciutats.size(); i++) {

			if (DatosPartida.ciutats.get(i).infeccion != 0) {

				Juego.ciudades[i].setVisible(true);

			} else {
				Juego.ciudades[i].setVisible(false);
			}

		}

	}

}
