package Main;

import Controlador.*;
import Model.*;
import Swing.*;

/**
 * Clase principal Main donde se abre la interfaz y la clase controlDatos que
 * soporta el inicio del juego
 * 
 */
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Marco();
		new ControlDatos();
		// ControlDatos.cargarJuego();

	}
}
