package Main;

import Controlador.*;
import Model.*;
import Swing.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new Marco();
		new ControlDatos();
		//ControlDatos.cargarJuego();
		

	}
}
